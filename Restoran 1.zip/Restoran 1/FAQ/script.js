document.addEventListener("DOMContentLoaded", function () {
    const collapseList = document.querySelectorAll(".collapse");
    const items = document.querySelectorAll(".col2 .list-group-item");
  
    collapseList.forEach(function (collapse) {
      collapse.addEventListener("show.bs.collapse", function () {
        collapseList.forEach(function (otherCollapse) {
          if (otherCollapse !== collapse) {
            otherCollapse.classList.remove("show");
          }
        });
      });
    });
  
    items.forEach((item) => {
      item.addEventListener("click", function () {
        if (this.classList.contains("clicked")) {
          this.classList.remove("clicked");
        } else {
          items.forEach((otherItem) => {
            otherItem.classList.remove("clicked");
          });
          this.classList.add("clicked");
        }
      });
    });
  });  